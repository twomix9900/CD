$(document).ready(function() {
  for (let i = 1; i < 16; i++) {
    let content = "<img src=http://pokeapi.co/media/img/";
    content += i;
    content += ".png>";
    $("#container").append(content);
  }
})