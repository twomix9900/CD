package com.cd.pets.models;

public interface Pet {
	String showAffection();
}
