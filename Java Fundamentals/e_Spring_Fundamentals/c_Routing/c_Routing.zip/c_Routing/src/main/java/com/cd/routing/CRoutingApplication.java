package com.cd.routing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CRoutingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CRoutingApplication.class, args);
	}
}
