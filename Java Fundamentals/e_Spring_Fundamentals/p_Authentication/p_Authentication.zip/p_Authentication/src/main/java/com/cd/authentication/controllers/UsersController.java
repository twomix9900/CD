package com.cd.authentication.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cd.authentication.models.User;
import com.cd.authentication.services.UserService;

@Controller
public class UsersController {
    private final UserService userService;
    
    public UsersController(UserService userService) {
        this.userService = userService;
    }
    
    @GetMapping("/registration")
    public String registerForm(@ModelAttribute("user") User user) {
        return "registrationPage.jsp";
    }
    @GetMapping("/login")
    public String login() {
        return "loginPage.jsp";
    }
    
    @PostMapping(value="/registration")
    public String registerUser(@Valid @ModelAttribute("user") User user, BindingResult result, HttpSession session) {
        // if result has errors, return the registration page (don't worry about validations just now)
        // else, save the user in the database, save the user id in session, and redirect them to the /home route
    	System.out.println(user.getPasswordConfirmation() + user.getPassword());
    	if (!user.getPassword().matches(user.getPasswordConfirmation())) {
    		System.out.println("Passwords don't match");
    		return "redirect:/registration";
    	} else {
    		System.out.println("Passwords match");
    		userService.registerUser(user);
    		session.setAttribute("userId", user.getId());
    		return "redirect:/home";
    	}
    }
    
    @PostMapping(value="/login")
    public String loginUser(@RequestParam("email") String email, @RequestParam("password") String password, Model model, HttpSession session) {
        if (userService.findByEmail(email) != null) {
        	if (userService.authenticateUser(email, password) == true) {
        		User user = userService.findByEmail(email);
        		session.setAttribute("userId", user.getId());
        		return "redirect:/home";
        	} else {
        		model.addAttribute("error", "invalid login credentials");
        		return "loginPage.jsp";
        	}
        } else {
        	model.addAttribute("error", "invalid login credentials");
        	return "loginPage.jsp";
        }
    }
    
    @GetMapping("/home")
    public String home(HttpSession session, Model model) {
        Long userId = (Long) session.getAttribute("Id");
        User user = userService.findUserById(userId);
        model.addAttribute("user", user);
        return "homePage.jsp";
    }
    @GetMapping("/logout")
    public String logout(HttpSession session) {
    	session.invalidate();
    	return "redirect:/login";
        // invalidate session
        // redirect to login page
    }
}