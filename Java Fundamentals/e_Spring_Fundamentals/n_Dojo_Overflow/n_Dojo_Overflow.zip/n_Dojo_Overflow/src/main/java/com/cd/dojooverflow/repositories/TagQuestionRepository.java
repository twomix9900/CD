package com.cd.dojooverflow.repositories;

public interface TagQuestionRepository {

}
