package com.cd.eventsbeltreviewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QEventsBeltReviewer2Application {

	public static void main(String[] args) {
		SpringApplication.run(QEventsBeltReviewer2Application.class, args);
	}
}
