package com.cd.counter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FCounterApplication {

	public static void main(String[] args) {
		SpringApplication.run(FCounterApplication.class, args);
	}
}
