package com.cd.displaydate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EDisplayDateApplication {

	public static void main(String[] args) {
		SpringApplication.run(EDisplayDateApplication.class, args);
	}
}
