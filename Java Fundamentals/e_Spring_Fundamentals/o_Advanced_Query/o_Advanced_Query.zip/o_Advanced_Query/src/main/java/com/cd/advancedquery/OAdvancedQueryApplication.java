package com.cd.advancedquery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OAdvancedQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(OAdvancedQueryApplication.class, args);
	}
}
