package com.cd.ninjagoldgame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class INinjaGoldGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(INinjaGoldGameApplication.class, args);
	}
}
