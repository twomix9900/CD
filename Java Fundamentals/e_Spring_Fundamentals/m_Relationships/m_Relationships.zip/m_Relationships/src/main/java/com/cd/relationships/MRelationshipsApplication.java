package com.cd.relationships;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MRelationshipsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MRelationshipsApplication.class, args);
	}
}
