package com.cd.thecode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GTheCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(GTheCodeApplication.class, args);
	}
}
